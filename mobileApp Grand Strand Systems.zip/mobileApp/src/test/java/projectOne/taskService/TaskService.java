package projectOne.taskService;

import java.util.ArrayList;

public class TaskService {

    private ArrayList<Task> tasks = new ArrayList<>();

    // Add task (must be unique ID)
    public void addTask(Task task) {

        if (task == null) {
            throw new IllegalArgumentException("Task cannot be null");
        }

        for (Task t : tasks) {
            if (t.getTaskId().equals(task.getTaskId())) {
                throw new IllegalArgumentException("Task ID must be unique");
            }
        }

        tasks.add(task);
    }

    // Delete task by ID
    public void deleteTask(String taskId) {

        Task taskToDelete = null;

        for (Task t : tasks) {
            if (t.getTaskId().equals(taskId)) {
                taskToDelete = t;
                break;
            }
        }

        if (taskToDelete == null) {
            throw new IllegalArgumentException("Task ID not found");
        }

        tasks.remove(taskToDelete);
    }

    // Update name by ID
    public void updateName(String taskId, String name) {

        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid name");
        }

        boolean found = false;

        for (Task t : tasks) {
            if (t.getTaskId().equals(taskId)) {
                t.setName(name);
                found = true;
                break;
            }
        }

        if (!found) {
            throw new IllegalArgumentException("Task ID not found");
        }
    }

    // Update description by ID
    public void updateDescription(String taskId, String description) {

        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }

        boolean found = false;

        for (Task t : tasks) {
            if (t.getTaskId().equals(taskId)) {
                t.setDescription(description);
                found = true;
                break;
            }
        }

        if (!found) {
            throw new IllegalArgumentException("Task ID not found");
        }
    }
}