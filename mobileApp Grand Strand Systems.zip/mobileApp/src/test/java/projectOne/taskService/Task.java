package projectOne.taskService;

public class Task {

    // Variables
    private final String taskId;
    private String name;
    private String description;

    // Constructor
    public Task(String taskId, String name, String description) {

        // Task ID validation
        if (taskId == null || taskId.trim().isEmpty() || taskId.length() > 10) {
            throw new IllegalArgumentException("Invalid task ID");
        }

        // Name validation
        if (name == null || name.trim().isEmpty() || name.length() > 20) {
            throw new IllegalArgumentException("Invalid name");
        }

        // Description validation
        if (description == null || description.trim().isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }

        // Assign values
        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    // Getters
    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    // Setter for name
    public void setName(String name) {

        if (name == null || name.trim().isEmpty() || name.length() > 20) {
            throw new IllegalArgumentException("Invalid name");
        }

        this.name = name;
    }

    // Setter for description
    public void setDescription(String description) {

        if (description == null || description.trim().isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }

        this.description = description;
    }
}