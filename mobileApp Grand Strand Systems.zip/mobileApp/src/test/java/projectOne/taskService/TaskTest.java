package projectOne.taskService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    // Test for valid task creation
    @Test
    public void testValidTask() {

        Task task = new Task(
                "001",
                "Task Name",
                "Task Description"
        );

        assertEquals("001", task.getTaskId());
        assertEquals("Task Name", task.getName());
        assertEquals("Task Description", task.getDescription());
    }

    // Test for null task ID
    @Test
    public void testNullTaskId() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Task(
                    null,
                    "Task Name",
                    "Task Description"
            );
        });
    }

    // Test for task ID too long
    @Test
    public void testTaskIdTooLong() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Task(
                    "12345678901",
                    "Task Name",
                    "Task Description"
            );
        });
    }

    // Test for null name
    @Test
    public void testNullName() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Task(
                    "001",
                    null,
                    "Task Description"
            );
        });
    }

    // Test for name too long
    @Test
    public void testNameTooLong() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Task(
                    "001",
                    "ThisNameIsDefinitelyWayTooLong",
                    "Task Description"
            );
        });
    }

    // Test for empty name (ADDED for stronger coverage)
    @Test
    public void testEmptyName() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Task(
                    "001",
                    "",
                    "Task Description"
            );
        });
    }

    // Test for null description
    @Test
    public void testNullDescription() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Task(
                    "001",
                    "Task Name",
                    null
            );
        });
    }

    // Test for description too long
    @Test
    public void testDescriptionTooLong() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Task(
                    "001",
                    "Task Name",
                    "This description is definitely longer than fifty characters long."
            );
        });
    }

    // Test for empty description (ADDED for stronger coverage)
    @Test
    public void testEmptyDescription() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Task(
                    "001",
                    "Task Name",
                    ""
            );
        });
    }
}