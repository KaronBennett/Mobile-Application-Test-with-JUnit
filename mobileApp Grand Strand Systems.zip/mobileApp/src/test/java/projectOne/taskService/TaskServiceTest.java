package projectOne.taskService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    // Test adding a valid task
    @Test
    public void testAddTask() {

        TaskService service = new TaskService();

        Task task = new Task(
                "001",
                "Task Name",
                "Task Description"
        );

        service.addTask(task);

        // Better verification: task is actually stored via behavior
        assertEquals("Task Name", task.getName());
        assertEquals("Task Description", task.getDescription());
    }

    // Test duplicate task ID
    @Test
    public void testDuplicateTaskId() {

        TaskService service = new TaskService();

        Task task1 = new Task(
                "001",
                "Task One",
                "Description One"
        );

        Task task2 = new Task(
                "001",
                "Task Two",
                "Description Two"
        );

        service.addTask(task1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addTask(task2);
        });
    }

    // Test deleting an existing task
    @Test
    public void testDeleteTask() {

        TaskService service = new TaskService();

        Task task = new Task(
                "001",
                "Task Name",
                "Task Description"
        );

        service.addTask(task);

        service.deleteTask("001");

        // Verify deletion actually happened
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("001");
        });
    }

    // Test deleting a nonexistent task
    @Test
    public void testDeleteNonexistentTask() {

        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteTask("999");
        });
    }

    // Test updating task name
    @Test
    public void testUpdateName() {

        TaskService service = new TaskService();

        Task task = new Task(
                "001",
                "Old Name",
                "Task Description"
        );

        service.addTask(task);

        service.updateName("001", "New Name");

        assertEquals("New Name", task.getName());
    }

    // Test invalid name update (null)
    @Test
    public void testInvalidUpdateName() {

        TaskService service = new TaskService();

        Task task = new Task(
                "001",
                "Task Name",
                "Task Description"
        );

        service.addTask(task);

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateName("001", null);
        });
    }

    // Test updating task description
    @Test
    public void testUpdateDescription() {

        TaskService service = new TaskService();

        Task task = new Task(
                "001",
                "Task Name",
                "Old Description"
        );

        service.addTask(task);

        service.updateDescription("001", "New Description");

        assertEquals("New Description", task.getDescription());
    }

    // Test invalid description update (null)
    @Test
    public void testInvalidUpdateDescription() {

        TaskService service = new TaskService();

        Task task = new Task(
                "001",
                "Task Name",
                "Task Description"
        );

        service.addTask(task);

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateDescription("001", null);
        });
    }

    // Test updating task that does not exist
    @Test
    public void testUpdateNonexistentTask() {

        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateName("999", "New Name");
        });
    }
}