package projectOne.appointmentService;

import java.util.ArrayList;

public class AppointmentService {

    private ArrayList<Appointment> appointments = new ArrayList<>();

    // Add appointment (must be unique ID)
    public void addAppointment (Appointment appointment) {

        if (appointment == null) {
            throw new IllegalArgumentException("Appointment cannot be null");
        }

        for (Appointment t : appointments) {
            if (t.getAppointmentId().equals(appointment.getAppointmentId())) {
                throw new IllegalArgumentException("Appointment ID must be unique");
            }
        }

        appointments.add(appointment);
    }

    // Delete appointment by ID
    public void deleteAppointment(String appointmentId) {

        Appointment appointmentToDelete = null;

        for (Appointment t : appointments) {
            if (t.getAppointmentId().equals(appointmentId)) {
                appointmentToDelete = t;
                break;
            }
        }

        if (appointmentToDelete == null) {
            throw new IllegalArgumentException("Appointment ID not found");
        }

        appointments.remove(appointmentToDelete);
    }


    // Update description by ID
    public void updateDescription(String appointmentId, String description) {

        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }

        boolean found = false;

        for (Appointment t : appointments) {
            if (t.getAppointmentId().equals(appointmentId)) {
                t.setDescription(description);
                found = true;
                break;
            }
        }

        if (!found) {
            throw new IllegalArgumentException("Task ID not found");
        }
    }
}
