package projectOne.appointmentService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.util.Date;

public class AppointmentServiceTest {

    // Test adding a valid appointment
    @Test
    public void testAddAppointment() {

        AppointmentService service = new AppointmentService();

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment appointment = new Appointment(
                "001",
                futureDate,
                "Appointment Description"
        );

        service.addAppointment(appointment);

        assertEquals("001", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Appointment Description", appointment.getDescription());
    }

    // Test duplicate appointment ID
    @Test
    public void testDuplicateAppointmentId() {

        AppointmentService service = new AppointmentService();

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment appointment1 = new Appointment(
                "001",
                futureDate,
                "Description One"
        );

        Appointment appointment2 = new Appointment(
                "001",
                futureDate,
                "Description Two"
        );

        service.addAppointment(appointment1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appointment2);
        });
    }

    // Test add null appointment
    @Test
    public void testAddNullAppointment() {

        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(null);
        });
    }

    // Test deleting an existing appointment
    @Test
    public void testDeleteAppointment() {

        AppointmentService service = new AppointmentService();

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment appointment = new Appointment(
                "001",
                futureDate,
                "Appointment Description"
        );

        service.addAppointment(appointment);

        service.deleteAppointment("001");

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("001");
        });
    }

    // Test deleting nonexistent appointment
    @Test
    public void testDeleteNonexistentAppointment() {

        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("999");
        });
    }

    // Test updating description
    @Test
    public void testUpdateDescription() {

        AppointmentService service = new AppointmentService();

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment appointment = new Appointment(
                "001",
                futureDate,
                "Old Description"
        );

        service.addAppointment(appointment);

        service.updateDescription("001", "New Description");

        assertEquals("New Description", appointment.getDescription());
    }

    // Test invalid update (null)
    @Test
    public void testInvalidUpdateDescription() {

        AppointmentService service = new AppointmentService();

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment appointment = new Appointment(
                "001",
                futureDate,
                "Valid Description"
        );

        service.addAppointment(appointment);

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateDescription("001", null);
        });
    }

    // Test update nonexistent appointment
    @Test
    public void testUpdateNonexistentAppointment() {

        AppointmentService service = new AppointmentService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateDescription("999", "New Description");
        });
    }

    // Test description too long
    @Test
    public void testUpdateDescriptionTooLong() {

        AppointmentService service = new AppointmentService();

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment appointment = new Appointment("001", futureDate, "Valid");
        service.addAppointment(appointment);

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateDescription("001",
                    "This description is too long, do not exceed 50 characters");
        });
    }

    // Boundary test: ID max length
    @Test
    public void testAppointmentIdBoundary() {

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        Appointment appointment = new Appointment(
                "1234567890",
                futureDate,
                "Valid Description"
        );

        assertEquals("1234567890", appointment.getAppointmentId());
    }

    // Boundary test: description max length
    @Test
    public void testDescriptionBoundary() {

        Date futureDate = new Date(System.currentTimeMillis() + 86400000);

        String desc = "12345678901234567890123456789012345678901234567890";

        Appointment appointment = new Appointment("001", futureDate, desc);

        assertEquals(desc, appointment.getDescription());
    }
}

