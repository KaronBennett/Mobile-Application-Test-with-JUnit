package projectOne.appointmentService;

import java.util.Date;

public class Appointment {

    // Variables
    private final String appointmentId;
    private Date appointmentDate;
    private String description;
    

    // Constructor
    public Appointment(String appointmentId, Date appointmentDate, String description) {

        // Appointment ID validation
        if (appointmentId == null || appointmentId.trim().isEmpty() || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Invalid appointment ID");
        }
        
        //Appointment Date validation
        if (appointmentDate == null) {
            throw new IllegalArgumentException("Appointment date cannot be null");
        }

        if (appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date cannot be in the past");
        }

        // Description validation
        if (description == null || description.trim().isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }
        
        

        // Assign values
        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    // Getters
    public String getAppointmentId() {
        return appointmentId;
    }

    public String getDescription() {
        return description;
    }
    
    public Date getAppointmentDate() {
        return appointmentDate;
    }

    // Setter for description
    public void setDescription(String description) {

        if (description == null || description.trim().isEmpty() || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }

        this.description = description;
    }
}
