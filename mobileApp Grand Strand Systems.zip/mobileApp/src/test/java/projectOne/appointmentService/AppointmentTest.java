package projectOne.appointmentService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.util.Date;

public class AppointmentTest {

    // Helper future date
    private Date getFutureDate() {
        return new Date(System.currentTimeMillis() + 86400000);
    }

    // Test valid appointment creation
    @Test
    public void testValidAppointment() {

        Date futureDate = getFutureDate();

        Appointment appointment = new Appointment(
                "001",
                futureDate,
                "Doctor Visit"
        );

        assertEquals("001", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Doctor Visit", appointment.getDescription());
    }

    // Test null appointment ID
    @Test
    public void testNullAppointmentId() {

        Date futureDate = getFutureDate();

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(
                    null,
                    futureDate,
                    "Doctor Visit"
            );
        });
    }

    // Test blank appointment ID
    @Test
    public void testBlankAppointmentId() {

        Date futureDate = getFutureDate();

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(
                    "   ",
                    futureDate,
                    "Doctor Visit"
            );
        });
    }

    // Test appointment ID too long
    @Test
    public void testAppointmentIdTooLong() {

        Date futureDate = getFutureDate();

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(
                    "12345678901",
                    futureDate,
                    "Doctor Visit"
            );
        });
    }

    // Test null appointment date
    @Test
    public void testNullAppointmentDate() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(
                    "001",
                    null,
                    "Doctor Visit"
            );
        });
    }

    // Test past appointment date
    @Test
    public void testPastAppointmentDate() {

        Date pastDate = new Date(System.currentTimeMillis() - 86400000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(
                    "001",
                    pastDate,
                    "Doctor Visit"
            );
        });
    }

    // Test null description
    @Test
    public void testNullDescription() {

        Date futureDate = getFutureDate();

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(
                    "001",
                    futureDate,
                    null
            );
        });
    }

    // Test empty description
    @Test
    public void testEmptyDescription() {

        Date futureDate = getFutureDate();

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(
                    "001",
                    futureDate,
                    ""
            );
        });
    }

    // Test blank description (spaces only)
    @Test
    public void testBlankDescription() {

        Date futureDate = getFutureDate();

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(
                    "001",
                    futureDate,
                    "     "
            );
        });
    }

    // Test description too long
    @Test
    public void testDescriptionTooLong() {

        Date futureDate = getFutureDate();

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(
                    "001",
                    futureDate,
                    "This description is definitely longer than fifty characters long which is invalid"
            );
        });
    }

    // Test valid description update
    @Test
    public void testSetDescriptionValid() {

        Appointment appointment = new Appointment(
                "001",
                getFutureDate(),
                "Doctor Visit"
        );

        appointment.setDescription("Updated Description");

        assertEquals(
                "Updated Description",
                appointment.getDescription()
        );
    }

    // Test null description in setter
    @Test
    public void testSetDescriptionNull() {

        Appointment appointment = new Appointment(
                "001",
                getFutureDate(),
                "Doctor Visit"
        );

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setDescription(null);
        });
    }

    // Test empty description in setter
    @Test
    public void testSetDescriptionEmpty() {

        Appointment appointment = new Appointment(
                "001",
                getFutureDate(),
                "Doctor Visit"
        );

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setDescription("");
        });
    }

    // Test description too long in setter
    @Test
    public void testSetDescriptionTooLong() {

        Appointment appointment = new Appointment(
                "001",
                getFutureDate(),
                "Doctor Visit"
        );

        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setDescription(
                    "This description is definitely longer than fifty characters long which is invalid"
            );
        });
    }
}