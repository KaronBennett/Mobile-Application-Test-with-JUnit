package projectOne.contactService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    // Helper to create valid contact
    private Contact createContact() {
        return new Contact(
                "001",
                "John",
                "Smith",
                "1234567890",
                "123 Main Street"
        );
    }


    // Add contact tests


    @Test
    public void testAddContact() {

        ContactService service = new ContactService();
        Contact contact = createContact();

        service.addContact(contact);

        assertTrue(true);
    }

    @Test
    public void testAddDuplicateContact() {

        ContactService service = new ContactService();

        service.addContact(createContact());

        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(createContact());
        });
    }


    // Delete contact tests


    @Test
    public void testDeleteContact() {

        ContactService service = new ContactService();
        service.addContact(createContact());

        service.deleteContact("001");

        assertTrue(true);
    }

    @Test
    public void testDeleteContactNotFound() {

        ContactService service = new ContactService();

        // Should execute loop but not find match
        service.deleteContact("999");

        assertTrue(true);
    }


    // Update first name


    @Test
    public void testUpdateFirstName() {

        ContactService service = new ContactService();
        Contact contact = createContact();

        service.addContact(contact);
        service.updateFirstName("001", "Mike");

        assertEquals("Mike", contact.getFirstName());
    }


    // Update last name


    @Test
    public void testUpdateLastName() {

        ContactService service = new ContactService();
        Contact contact = createContact();

        service.addContact(contact);
        service.updateLastName("001", "Brown");

        assertEquals("Brown", contact.getLastName());
    }


    // Update phone


    @Test
    public void testUpdatePhone() {

        ContactService service = new ContactService();
        Contact contact = createContact();

        service.addContact(contact);
        service.updatePhone("001", "0987654321");

        assertEquals("0987654321", contact.getPhone());
    }


    // Update address


    @Test
    public void testUpdateAddress() {

        ContactService service = new ContactService();
        Contact contact = createContact();

        service.addContact(contact);
        service.updateAddress("001", "456 New Street");

        assertEquals("456 New Street", contact.getAddress());
    }


    // Updated non-existent contact (loop branch)
   

    @Test
    public void testUpdateNonExistentContact() {

        ContactService service = new ContactService();

        // Executes loops but never matches ID
        service.updateFirstName("999", "Mike");
        service.updateLastName("999", "Brown");
        service.updatePhone("999", "1234567890");
        service.updateAddress("999", "Nowhere");

        assertTrue(true);
    }
}