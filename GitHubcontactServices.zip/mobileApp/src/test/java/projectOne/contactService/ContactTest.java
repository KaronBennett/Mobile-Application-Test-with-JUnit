package projectOne.contactService;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {



// Constructor tests


    @Test
    public void testValidContact() {

        Contact contact = new Contact(
                "001",
                "John",
                "Smith",
                "1234567890",
                "123 Main Street"
        );

        assertTrue(contact.getContactId().equals("001"));
    }

    @Test
    public void testInvalidContactId() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(
                    "12345678901",
                    "John",
                    "Smith",
                    "1234567890",
                    "123 Main Street"
            );
        });
    }

    @Test
    public void testInvalidFirstName() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(
                    "001",
                    null,
                    "Smith",
                    "1234567890",
                    "123 Main Street"
            );
        });
    }

    @Test
    public void testInvalidFirstNameTooLong() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(
                    "001",
                    "ThisFirstNameTooLong",
                    "Smith",
                    "1234567890",
                    "123 Main Street"
            );
        });
    }

    @Test
    public void testInvalidLastNameNull() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(
                    "001",
                    "John",
                    null,
                    "1234567890",
                    "123 Main Street"
            );
        });
    }

    @Test
    public void testInvalidLastNameTooLong() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(
                    "001",
                    "John",
                    "ThisLastNameTooLong",
                    "1234567890",
                    "123 Main Street"
            );
        });
    }

    @Test
    public void testInvalidPhone() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(
                    "001",
                    "John",
                    "Smith",
                    "12345",
                    "123 Main Street"
            );
        });
    }

    @Test
    public void testInvalidPhoneNull() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(
                    "001",
                    "John",
                    "Smith",
                    null,
                    "123 Main Street"
            );
        });
    }

    @Test
    public void testInvalidPhoneNonDigit() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(
                    "001",
                    "John",
                    "Smith",
                    "ABCDEFGHIJ",
                    "123 Main Street"
            );
        });
    }

    @Test
    public void testInvalidAddress() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(
                    "001",
                    "John",
                    "Smith",
                    "1234567890",
                    "This address is definitely longer than thirty characters"
            );
        });
    }

    @Test
    public void testInvalidAddressNull() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(
                    "001",
                    "John",
                    "Smith",
                    "1234567890",
                    null
            );
        });
    }


    // Setter tests

    @Test
    public void testSetFirstNameValid() {

        Contact contact = new Contact(
                "001",
                "John",
                "Smith",
                "1234567890",
                "123 Main Street"
        );

        contact.setFirstName("Mike");

        assertEquals("Mike", contact.getFirstName());
    }

    @Test
    public void testSetFirstNameNull() {

        Contact contact = new Contact(
                "001",
                "John",
                "Smith",
                "1234567890",
                "123 Main Street"
        );

        assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName(null);
        });
    }

    @Test
    public void testSetFirstNameTooLong() {

        Contact contact = new Contact(
                "001",
                "John",
                "Smith",
                "1234567890",
                "123 Main Street"
        );

        assertThrows(IllegalArgumentException.class, () -> {
            contact.setFirstName("ThisNameIsTooLong");
        });
    }

    @Test
    public void testSetLastNameValid() {

        Contact contact = new Contact(
                "001",
                "John",
                "Smith",
                "1234567890",
                "123 Main Street"
        );

        contact.setLastName("Brown");

        assertEquals("Brown", contact.getLastName());
    }

    @Test
    public void testSetLastNameNull() {

        Contact contact = new Contact(
                "001",
                "John",
                "Smith",
                "1234567890",
                "123 Main Street"
        );

        assertThrows(IllegalArgumentException.class, () -> {
            contact.setLastName(null);
        });
    }

    @Test
    public void testSetLastNameTooLong() {

        Contact contact = new Contact(
                "001",
                "John",
                "Smith",
                "1234567890",
                "123 Main Street"
        );

        assertThrows(IllegalArgumentException.class, () -> {
            contact.setLastName("ThisLastNameIsTooLong");
        });
    }

    @Test
    public void testSetPhoneValid() {

        Contact contact = new Contact(
                "001",
                "John",
                "Smith",
                "1234567890",
                "123 Main Street"
        );

        contact.setPhone("0987654321");

        assertEquals("0987654321", contact.getPhone());
    }

    @Test
    public void testSetPhoneNull() {

        Contact contact = new Contact(
                "001",
                "John",
                "Smith",
                "1234567890",
                "123 Main Street"
        );

        assertThrows(IllegalArgumentException.class, () -> {
            contact.setPhone(null);
        });
    }

    @Test
    public void testSetPhoneInvalidFormat() {

        Contact contact = new Contact(
                "001",
                "John",
                "Smith",
                "1234567890",
                "123 Main Street"
        );

        assertThrows(IllegalArgumentException.class, () -> {
            contact.setPhone("ABCDE12345");
        });
    }

    @Test
    public void testSetAddressValid() {

        Contact contact = new Contact(
                "001",
                "John",
                "Smith",
                "1234567890",
                "123 Main Street"
        );

        contact.setAddress("456 New Street");

        assertEquals("456 New Street", contact.getAddress());
    }

    @Test
    public void testSetAddressNull() {

        Contact contact = new Contact(
                "001",
                "John",
                "Smith",
                "1234567890",
                "123 Main Street"
        );

        assertThrows(IllegalArgumentException.class, () -> {
            contact.setAddress(null);
        });
    }

    @Test
    public void testSetAddressTooLong() {

        Contact contact = new Contact(
                "001",
                "John",
                "Smith",
                "1234567890",
                "123 Main Street"
        );

        assertThrows(IllegalArgumentException.class, () -> {
            contact.setAddress("This address is way too long and exceeds thirty characters limit");
        });
    }
}