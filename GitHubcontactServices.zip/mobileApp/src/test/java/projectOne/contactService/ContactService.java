package projectOne.contactService;

import java.util.ArrayList;

public class ContactService {

    private ArrayList<Contact> contacts = new ArrayList<>();

    // Add contact
    public void addContact(Contact contact) {

        // Check for duplicate ID
        for (Contact c : contacts) {
            if (c.getContactId().equals(contact.getContactId())) {
                throw new IllegalArgumentException("Contact ID already exists");
            }
        }

        contacts.add(contact);
    }

    // Delete contact
    public void deleteContact(String contactId) {

        Contact contactToDelete = null;

        for (Contact c : contacts) {
            if (c.getContactId().equals(contactId)) {
                contactToDelete = c;
            }
        }

        if (contactToDelete != null) {
            contacts.remove(contactToDelete);
        }
    }

    // Update first name
    public void updateFirstName(String contactId, String firstName) {

        for (Contact c : contacts) {
            if (c.getContactId().equals(contactId)) {
                c.setFirstName(firstName);
            }
        }
    }

    // Update last name
    public void updateLastName(String contactId, String lastName) {

        for (Contact c : contacts) {
            if (c.getContactId().equals(contactId)) {
                c.setLastName(lastName);
            }
        }
    }

    // Update phone
    public void updatePhone(String contactId, String phone) {

        for (Contact c : contacts) {
            if (c.getContactId().equals(contactId)) {
                c.setPhone(phone);
            }
        }
    }

    // Update address
    public void updateAddress(String contactId, String address) {

        for (Contact c : contacts) {
            if (c.getContactId().equals(contactId)) {
                c.setAddress(address);
            }
        }
    }
}